import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import BuyTicket from './pages/BuyTicket'
import Print from './pages/Print';
import Print2 from './pages/Print2';
import Print3 from './pages/Print3';
import PhotoPlay from './pages/Photoplay'
import './styles/common.css';
import TrailerPlayer from './components/shared/TrailerPlayer'

function App() {
  return (
    <div className="app-container">
      <div className="trailer-container">
        <TrailerPlayer />
      </div>
      
      <div className="page-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ticket" element={<BuyTicket />} />
          <Route path="/print" element={<Print />} />
          <Route path="/print2" element={<Print2 />} />
          <Route path="/print3" element={<Print3 />} />
          <Route path="/photoplay" element={<PhotoPlay />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
