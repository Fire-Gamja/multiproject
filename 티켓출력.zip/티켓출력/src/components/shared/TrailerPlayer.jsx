import React, { useEffect, useState } from 'react';
// import ReactPlayer from 'react-player';

function TrailerPlayer() {
  const [videoUrls, setVideoUrls] = useState([]);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(true);
  const [hasInteracted, setHasInteracted] = useState(false);

  useEffect(() => {
    fetch('http://localhost:8000/api/videos/')
      .then(res => res.json())
      .then(data => {
        const urls = data.map(video => video.url);
        setVideoUrls(urls);
      })
      .catch(err => console.error('영상 로딩 실패:', err));
  }, []);

  const handleEnded = () => {
    setCurrentVideoIndex((prevIndex) => (prevIndex + 1) % videoUrls.length);
  };

  const handleUnmute = () => {
    setIsMuted(false);
    setHasInteracted(true);
  };

  if (videoUrls.length === 0) return null;

  return (
    <div className="trailer-player" style={{ pointerEvents: 'none' }}>
      <video
        src={videoUrls[currentVideoIndex]}
        loop={true}
        autoPlay
        muted={isMuted}
        playsInline
        onEnded={handleEnded}
        style={{ 
          width: "1080px",
          height: "608px",
          objectFit: 'cover',
        }}
      />
      {!hasInteracted && (
        <button onClick={handleUnmute} className='unmute-btn' style={{ pointerEvents: 'auto' }}>
          Click to Unmute
        </button>
      )}
    </div>
  );
}

export default TrailerPlayer;
