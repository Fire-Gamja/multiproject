import React, { useEffect, useState } from 'react';
import '../../styles/BuyTicket.css';

function MovieCard() {
  const [movies, setMovies] = useState([]);

  // 백엔드 API 호출
  useEffect(() => {
    fetch('http://localhost:8000/api/movies/')
      .then(res => res.json())
      .then(data => setMovies(data))
      .catch(err => console.error('영화 불러오기 실패:', err));
  }, []);

  return (
    <div className="movie-list">
      {movies.map((movie) => (
        <div key={movie.id} className="movie-card">
          <div className="age-rating">{movie.age}</div>
          <img src={movie.poster} alt={movie.title} className="movie-poster" />
          <div className="movie-info">
            <div className="movie-meta">
              <span className="movie-time">{movie.time}</span>
            </div>
            <div className="movie-title">              
              <span className="movie-seats">{movie.seats}</span>
              <br />
              <span className="movie-title">{movie.title}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default MovieCard;
