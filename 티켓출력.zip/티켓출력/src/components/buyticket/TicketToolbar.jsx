import React, { useEffect, useState } from 'react';
import '../../styles/BuyTicket.css';
import { useTranslation } from 'react-i18next';
import timer from "../../assets/clock_logo.svg"

function TicketToolbar() {
  const { t } = useTranslation();
  const [timeLeft, setTimeLeft] = useState(30 * 60);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime <= 0) {
          clearInterval(timer);
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div>
      <div className='ticket-timer'>
        <img src={timer} alt="시계 아이콘" />
        <p>{`${minutes}:${seconds < 10 ? '0' : ''}${seconds}`}</p>
      </div>
      <div className="ticket-toolbar">
        <button className="ghost-button">{t('changeCinema')}</button>
        <button className="ghost-button">{t('viewSchedule')}</button>
      </div>
    </div>
  );
}

export default TicketToolbar;
