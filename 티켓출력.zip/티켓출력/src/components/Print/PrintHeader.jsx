import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../../styles/Print.css';
import CJONElogo from '../../assets/cjone_logo.svg';
import Home from '../../assets/home_logo.svg';
import { useTranslation } from 'react-i18next';

function PrintHeader() {
  const navigate = useNavigate();
  const { t } = useTranslation();

  return (
    <header className="print-header">
      <div className="logo">
        <button className="back-button" onClick={() => navigate(-1)}>&lt;</button>
        <p></p>
        <br />
        <p style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t('cinema')}</p>
      </div>

      <h2 className="print-title" style={{ textAlign: 'center' }}>{t('print')}</h2>

      <div className="print-back">
        <button className="home-button" onClick={() => navigate('/')}>
          <img className='print-home-button' src={Home} alt="home button" />
        </button>
        <img className='print-cjlogo' src={CJONElogo} alt="CJONE Logo" />
      </div>
    </header>
  );
}

export default PrintHeader;
