import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const NumberInput = () => {
    const [inputValue, setInputValue] = useState('');

    const formatInputValue = (value) => {
        let formattedValue = value.replace(/-/g, '');
        return formattedValue.replace(/(\d{4})(?=\d)/g, '$1-');
    };

    const handleNumberClick = (number) => {
        setInputValue((prev) => {
            const newValue = prev.replace(/-/g, '') + number;
            return formatInputValue(newValue);
        });
    };

    const handleClear = () => {
        setInputValue('');
    };
    const [isPressed, setIsPressed] = useState(false);
    const navigate = useNavigate();
    const handleClick = () => {
        navigate('/print3'); // 여기에 이동할 경로 넣기
      };

    return (
        <div className="number-input-container">
            <p className="number-input-instructions">
                예매번호 15자리를 입력해주세요.<br></br>
                예매번호를 모르는 고객님은 휴대폰번호로 조회해 주세요.
            </p>
            <div className="number-input-wrapper">
                <input
                    type="text"
                    value={inputValue}
                    readOnly
                    className="number-input-display"
                    placeholder="예매번호(15자)"
                />
                <button
                    onClick={handleClear}
                    className="number-input-clear-button unique-clear-button"
                >
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="number-input-clear-icon"
                        width="16"
                        height="16"
                    >
                        <line x1="18" y1="6" x2="6" y2="18" />
                        <line x1="6" y1="6" x2="18" y2="18" />
                    </svg>
                </button>
            </div>
            <div className="number-input-grid">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((number) => (
                    <button
                        key={number}
                        onClick={() =>
                            setInputValue((prev) => {
                                const newValue = prev.replace(/-/g, '') + number;
                                if (newValue.length > 15) return prev;
                                return formatInputValue(newValue);
                            })
                        }
                        className={`number-input-button number-input-button-${number}`}
                    >
                        {number}
                    </button>
                ))}
                <button
                    onClick={() =>
                        setInputValue((prev) =>
                            formatInputValue(prev.slice(0, -1))
                        )
                    }
                    className="number-input-button clear-button unique-clear-grid-button"
                >
                    지우기
                </button>
                <button
                    onClick={() =>
                        setInputValue((prev) => {
                            const newValue = prev.replace(/-/g, '') + '0';
                            if (newValue.length > 15) return prev;
                            return formatInputValue(newValue);
                        })
                    }
                    className="number-input-button number-input-button-0"
                >
                    0
                </button>
                <button
                    className="number-input-button-hidden unique-hidden-button"
                    disabled
                >
                    .
                </button>
            </div>
            <div className="number-input-actions">
                <button className={`number-input-action-button1 ${isPressed ? 'pressed' : ''}`}
                onMouseDown={() => setIsPressed(true)}
                onMouseUp={() => setIsPressed(false)}
                onMouseLeave={() => setIsPressed(false)} // 마우스 벗어날 때도 초기화
                onClick={handleClick}>
                    티켓조회
                </button>
                <button className="number-input-action-button2">
                    CJONE바코드/모바일티켓으로 조회
                </button>
            </div>
        </div>
    );
};

export default NumberInput;