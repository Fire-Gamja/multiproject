import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import '../../styles/Print.css';

function Check() {
  const [activeTab, setActiveTab] = useState('reservation');
  const { t } = useTranslation();

  return (
    <div className="check-container">
      <div className="tab-buttons">
        <button 
          className={`tab-button ${activeTab === 'reservation' ? 'active' : ''}`}
          onClick={() => setActiveTab('reservation')}
        >
          예매번호로 조회
        </button>
        <button 
          className={`tab-button ${activeTab === 'phone' ? 'active' : ''}`}
          onClick={() => setActiveTab('phone')}
        >
          휴대폰번호로 조회
        </button>
      </div>
    </div>
  );
}

export default Check;