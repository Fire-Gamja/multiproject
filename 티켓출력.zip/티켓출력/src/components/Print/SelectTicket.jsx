import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../../styles/Print.css';

const SelectTicket = () => {
    return (
        <div className="select-ticket-container">
            <div className="left-section">
                <div className="thumbnail">
                    <img src="thumbnail-placeholder.jpg" alt="Thumbnail" />
                </div>
            </div>
            <div className="right-section">
                <div className="movie-title">
                    <img src="icon-placeholder.png" alt="Icon" className="icon" />
                    <input type="text" placeholder="영화 제목 입력" />
                </div>
                <div className="long-text-box">
                    <input type="text" placeholder="텍스트 입력" />
                </div>
                <div className="theater-info">
                    <span>상영관 정보</span>
                </div>
                <div className="date-info">
                    <span>날짜</span>
                </div>
            </div>
        </div>
    );
};

export default SelectTicket;