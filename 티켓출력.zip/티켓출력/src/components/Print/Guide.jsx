import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import GuideImg from '../../assets/guide_image.png';
import '../../styles/Print.css';

const Guide = () => {
    const [isPressed, setIsPressed] = useState(false);
    const navigate = useNavigate();

    const handleClick = () => {
        navigate('/print2'); // 여기에 이동할 경로 넣기
      };

    return (
        <div style={{ textAlign: 'center', padding: '20px' }}>
            <img 
                src={GuideImg}
                alt="Guide" 
                style={{ maxWidth: '27rem', height: 'auto', marginBottom: '20px', borderRadius: '15px'}} 
            />
            <p style={{ fontSize: '24px', color: '#555', marginBottom: '20px' }}>
                예매하신 모바일 티켓의<br></br>바코드/QR코드를 바코드 스캐너에 대어 주세요.
            </p>
            <button
                className={`guide-button ${isPressed ? 'pressed' : ''}`}
                onMouseDown={() => setIsPressed(true)}
                onMouseUp={() => setIsPressed(false)}
                onMouseLeave={() => setIsPressed(false)} // 마우스 벗어날 때도 초기화
                onClick={handleClick}
            >
                예매번호로 조회
            </button>
        </div>
    );
};

export default Guide;