import { Routes, Route, useLocation } from 'react-router-dom';
import PrintHeader from '../components/Print/PrintHeader';
import Check from '../components/Print/Check';
import '../styles/Print.css';
import Guide from '../components/Print/Guide';

function Print() {
    return (
        <div className="print">
            <PrintHeader />
            <Check />
            <Guide />
        </div>
    );
}

export default Print;