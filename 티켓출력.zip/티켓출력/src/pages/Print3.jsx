import { Routes, Route, useLocation } from 'react-router-dom';
import PrintHeader from '../components/Print/PrintHeader';
import '../styles/Print.css';
import Check from '../components/Print/Check';
import SelectTicket from '../components/Print/SelectTicket';


function Print3() {
    return (
        <div className="print3">
            <PrintHeader />
            <Check />
            {/* <SelectTicket /> */}
        </div>
    );
}

export default Print3;