import { Routes, Route, useLocation } from 'react-router-dom';
import PrintHeader from '../components/Print/PrintHeader';
import '../styles/Print.css';
import NumberInput from '../components/Print/NumberInput';
import Check from '../components/Print/Check';


function Print2() {
    return (
        <div className="print2">
            <PrintHeader />
            <Check />
            <NumberInput />
        </div>
    );
}

export default Print2;