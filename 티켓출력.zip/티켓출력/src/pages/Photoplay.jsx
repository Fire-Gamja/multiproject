import React from 'react';
import Header from '../components/photoplay/PhotoplayHeader'
import '../styles/PhotoPlay.css';

function Photoplay() {
    return (
    <div className="buyTicket">
        <Header />
        <div className="scroll-area">
         {/* 추후 추가 예정 */}
        </div>
    </div>
    );
}

export default Photoplay;