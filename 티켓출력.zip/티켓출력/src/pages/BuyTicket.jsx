import React from 'react';
import Header from '../components/buyticket/BuyTicketHeader'
import MovieCard from '../components/buyticket/MovieCard';
import TicketToolbar from '../components/buyticket/TicketToolbar';
import '../styles/BuyTicket.css';

function BuyTicket() {
    return (
    <div className="buyTicket">
        <Header />
        <TicketToolbar />
        <div className="scroll-area">
            <MovieCard />
        </div>
    </div>
    );
}

export default BuyTicket;